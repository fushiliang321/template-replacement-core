mod extract;
pub mod office;
mod replace;

use crate::office::excel::new as new_excel;
use crate::office::office::Office;
use crate::office::word::new as new_word;
use crate::office::zip::Zip;
use crate::replace::data::Value::Text;
use crate::replace::data::{encode, Data};
use crate::replace::index::Replace;
use async_std::prelude::*;
use futures::future::join_all;
use std::any::Any;
use std::collections::HashMap;
use std::fs;
use std::fs::{read_dir, DirEntry, File};
use std::io::{BufWriter, Error, ErrorKind, Read, Write};
use std::time::Instant;

#[async_std::main]
async fn main() {
    // let path = "D:\\其他\\test";
    let path = "D:\\其他\\A 人权生成模板2022简";
    // let img = "D:\\其他\\QQ截图20240730160807.jpg";
    // let img = fs::read(img).unwrap();


    let variables = Data {
        text: Option::from(HashMap::from([
            (String::from("${公司名}"), Text(encode("xxxx公<>司"))),
            (String::from("${文件编号}"), Text("123456789".parse().unwrap())),
            // (String::from("${公司名}"), Image(replace::image::new(
            //     generate_id(&img),
            //     img.into_boxed_slice(),
            //     "".parse().unwrap(),
            //     replace::image::TextWrapType::Embed,
            //     Extent {
            //         cx: 91440f32,
            //         cy: 91440f32,
            //     },
            // ))),
        ])),
        media: None,
    };


    if let Ok(_dir) = read_dir(path) {
        let mut files: Vec<Zip> = Vec::new();
        let mut names: Vec<String> = Vec::new();
        for entry in _dir {
            if let Ok(_entry) = entry {
                if !_entry.file_type().unwrap().is_file() {
                    continue;
                }
                let name = _entry.file_name().to_str().unwrap().to_string();
                if let Ok(office) = open_office(_entry).await {
                    files.push(office);
                    names.push(name);
                }
            }
        }

        let start = Instant::now();
        let files = Replace::new(files, variables).execute().await;
        let mut file_map = HashMap::new();
        for i in 0..files.len() {
            file_map.insert(names.get(i).unwrap(), files.get(i).unwrap());
        }
        export(file_map);
        println!("耗时: {:?}", start.elapsed());
    }
}

async fn open_office(_entry: DirEntry) -> Result<Zip, Error> {
    match _entry.path().extension() {
        Some(ext) => match ext.to_str() {
            Some(str) => match str {
                "docx" => {
                    let path = _entry.path().to_string_lossy().into_owned();
                    let file = fs::read(path).unwrap();
                    let office = new_word(file).await?;
                    return Ok(office);
                }
                "xlsx" => {
                    let path = _entry.path().to_string_lossy().into_owned();
                    let file = fs::read(path).unwrap();
                    let office = new_excel(file).await?;
                    return Ok(office);
                }
                _ => {}
            },
            _ => {}
        },
        _ => {}
    }
    Err(Error::new(ErrorKind::Other, "不支持的文件类型"))
}

fn export(files: HashMap<&String, &Box<[u8]>>) {
    for (name, file) in files.iter() {
        // 将内存中的数据写入文件
        if let Ok(output_file) = File::create("./out/".to_owned() + name) {
            let mut writer = BufWriter::new(output_file);
            if let Ok(_) = writer.write(file.as_ref()) {
                writer.flush();
            }
        }
    }
}

async fn export_to_path(path: String, data: &[u8]) {
    if let Ok(mut file) = async_std::fs::File::create(path).await {
        file.write_all(data.as_ref()).await;
    }
}

async fn async_export(files: HashMap<&String, &Box<[u8]>>) {
    let mut tasks = vec![];
    for (name, data) in files.iter() {
        // 将内存中的数据写入文件
        let path = "./out/".to_owned() + name;
        let data = data.as_ref();
        tasks.push(export_to_path(path, data));
    }
    join_all(tasks).await;
}
